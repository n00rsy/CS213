package com.cs213.tuitionmanagerfx.model.enums;

/**
 * An enum class for Majors that a student can have.
 *
 * @author Noor, Umar
 */
public enum Major {
    CS, IT, BA, EE, ME
}
