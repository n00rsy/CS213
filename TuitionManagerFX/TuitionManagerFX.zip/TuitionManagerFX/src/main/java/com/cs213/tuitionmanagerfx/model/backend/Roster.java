package com.cs213.tuitionmanagerfx.model.backend;

import com.cs213.tuitionmanagerfx.model.backend.student.International;
import com.cs213.tuitionmanagerfx.model.backend.student.Resident;
import com.cs213.tuitionmanagerfx.model.backend.student.Student;
import com.cs213.tuitionmanagerfx.model.config.Constants;
import com.cs213.tuitionmanagerfx.model.util.ArrayUtil;

/**
 * A class that defines a mutable, dynamically resizable list of Students that can be interacted with.
 *
 * @author Noor, Umar
 */
public class Roster {

    private Student[] roster;
    private int size; //keep track of the number of students in the roster

    /**
     * Initializes a new roster.
     */
    public Roster() {
        roster = new Student[Constants.ROSTER_INITIAL_SIZE];
        size = 0;
    }

    /**
     * Iterates through this roster to find the index of the student, or returns NOT_FOUND.
     *
     * @param student the student to search for
     * @return index of the student, or NOT_FOUND if it is not found
     */
    private int find(Student student) {
        for (int i = 0; i < size; i++) {
            if (student.equals(roster[i])) {
                return i;
            }
        }
        return Constants.NOT_FOUND;
    }

    /**
     * Increase the capacity of the inner array by 4.
     */
    private void grow() {
        Student[] newRoster = new Student[roster.length + Constants.ROSTER_GROWTH_AMOUNT];

        for (int i = 0; i < size; i++) {
            newRoster[i] = roster[i];
        }
        roster = newRoster;
    }

    /**
     * Attempts to add the student to the list.
     *
     * @param student the student to add
     * @return True if added, false otherwise.
     */
    public boolean add(Student student) {
        if (find(student) >= 0) {
            return false;
        }

        if (size == roster.length) {
            grow();
        }
        roster[size] = student;
        size++;
        return true;
    }

    /**
     * Removes the student from the list.
     *
     * @param student the student to remove.
     * @return True if removed, false otherwise.
     */
    public boolean remove(Student student) {
        int studentIndex = find(student);
        if (studentIndex < 0) {
            return false;
        }

        for (int i = studentIndex; i < roster.length - 1; i++) {
            roster[i] = roster[i + 1];
        }
        roster[roster.length - 1] = null;

        size--;
        return true;
    }

    /**
     * Finds the student in the roster array, then pays the inputted tuition amount and updates lastPaymentDate
     *
     * @param student the student to update
     * @param amount  the amount of tuition to pay
     * @param date    the date of the payment
     * @return true if success, false otherwise.
     */
    public boolean payTuition(Student student, double amount, Date date) {
        int studentIndex = find(student);
        if (studentIndex < 0) {
            return false;
        }

        if (amount > roster[studentIndex].getTuitionDueAmount()) {
            throw new IllegalArgumentException("Amount is greater than amount due.");
        }
        roster[studentIndex].payTuition(amount, date);
        return true;
    }

    /**
     * Finds the student in the roster array, then sets the study abroad status to the inputted value
     *
     * @param student the student to find
     * @param status  the new status
     * @return true if success, false otherwise.
     */
    public boolean setStudyAbroad(Student student, boolean status) {
        int studentIndex = find(student);
        if (studentIndex < 0) {
            return false;
        }
        try {
            International internationalStudent = (International) roster[studentIndex];
            internationalStudent.setStudyAbroad(status);
            if (status) {
                if (internationalStudent.getNumCredits() > 12) internationalStudent.setNumCredits(12);
                internationalStudent.tuitionDue();
                internationalStudent.setTuitionPayment(0);
                internationalStudent.setLastPaymentDate(new Date(Constants.DEFAULT_DATE));
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Finds the student in the roster array, then sets the financial aid to inputted amount
     *
     * @param student the student to find
     * @param amount  the amount of financial aid
     * @return true if success, false otherwise.
     */
    public boolean setFinancialAid(Student student, double amount) {
        int studentIndex = find(student);
        if (studentIndex < 0) {
            return false;
        }
        Resident resident;
        try {
            resident = (Resident) roster[studentIndex];

        } catch (Exception e) {
            throw new IllegalStateException("Not a resident student.");
        }
        if (resident.isPartTime()) {
            throw new IllegalStateException("Parttime student doesn't qualify for the award.");
        }
        if (resident.getFinancialAid() > 0) {
            throw new IllegalStateException("Awarded once already.");
        }
        resident.setFinancialAid(amount);
        return true;
    }

    /**
     * Iterates through the entire roster and calculates tuition due for each student.
     */
    public void calculateTuition() {
        for (int i = 0; i < size; i++) {
            roster[i].tuitionDue();
        }
    }

    /**
     * Returns all students in the roster, unordered.
     *
     * @return Student[] unordered array of students in the roster
     */
    public Student[] getRoster() {
        if (size == 0) {
            throw new IllegalStateException(Constants.EMPTY_ROSTER_MESSAGE);
        } else {
            Student[] newArray = new Student[size];
            for (int i = 0; i < size; i++) {
                newArray[i] = roster[i];
            }
            return newArray;
        }
    }

    public void print() {
        ArrayUtil.print(roster, 0, size);
    }

    /**
     * Returns all students in the roster, sorted by name in ascending order
     *
     * @return Student[] array of students in the roster ordered by name
     */
    public Student[] getRosterByStudentName() {
        if (size == 0) {
            throw new IllegalStateException(Constants.EMPTY_ROSTER_MESSAGE);
        } else {
            Object[] trimmedRoster = ArrayUtil.copy(roster, 0, size);
            ArrayUtil.insertionSort(trimmedRoster, (o1, o2) -> {
                Student s1 = (Student) o1;
                Student s2 = (Student) o2;
                return s1.getProfile().getName().compareTo(s2.getProfile().getName());
            });
            Student[] students = new Student[trimmedRoster.length];
            for (int i = 0; i < trimmedRoster.length; i++) {
                students[i] = (Student) trimmedRoster[i];
            }
            return students;
        }
    }

    /**
     * Returns students who have made a tuition payment, sorted by last payment date in descending order
     *
     * @return students who paid tuition ordered by last payment date
     */
    public Student[] getPaymentStudentsByPaymentDate() {
        if (size == 0) {
            throw new IllegalStateException(Constants.EMPTY_ROSTER_MESSAGE);
        } else {
            Object[] trimmedRoster = ArrayUtil.copy(roster, 0, size);

            for (int i = 0; i < trimmedRoster.length; i++) {
                Student s = (Student) trimmedRoster[i];
                if (s.getLastPaymentDate().compareTo(new Date(Constants.DEFAULT_DATE)) == 0) {
                    trimmedRoster[i] = null;
                }
            }
            Object[] payingStudents = ArrayUtil.filterNullValues(trimmedRoster);

            ArrayUtil.insertionSort(payingStudents, (o1, o2) -> {
                Student s1 = (Student) o1;
                Student s2 = (Student) o2;
                return s1.getLastPaymentDate().compareTo(s2.getLastPaymentDate());
            });
            Student[] students = new Student[payingStudents.length];
            for (int i = 0; i < payingStudents.length; i++) {
                students[i] = (Student) payingStudents[i];
            }
            return students;
        }
    }
}
