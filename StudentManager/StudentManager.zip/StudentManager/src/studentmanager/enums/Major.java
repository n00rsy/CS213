package studentmanager.enums;

/**
 * An enum class for Majors that a student can have.
 *
 * @author Noor, Umar
 */
public enum Major {
    CS, IT, BA, EE, ME
}
